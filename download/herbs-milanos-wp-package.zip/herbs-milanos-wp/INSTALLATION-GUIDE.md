# Herbs Milanos — دليل تثبيت WordPress

## المتطلبات
- WordPress 6.0+
- PHP 8.1+
- استضافة تدعم WordPress (SiteGround, Cloudways, أو أي استضافة Litespeed)

---

## الخطوة 1: تثبيت القالب

1. **افتح لوحة WordPress** (`/wp-admin`)
2. اذهب إلى: **Appearance → Themes → Add New → Upload Theme**
3. **ارفع ملف** `herbs-milanos-theme.zip`
4. اضغط **Install Now** ثم **Activate**

## الخطوة 2: تثبيت الإضافات المطلوبة

ثبّت هذه الإضافات (Plugins → Add New):

### إضافات أساسية:
1. **Advanced Custom Fields (ACF)** — لحقول المواصفات الفنية
2. **WPML** أو **Polylang** — لدعم العربية/الإنجليزية
3. **WP Mail SMTP** — لضمان وصول إيميلات نموذج RFQ
4. **Wordfence Security** — للحماية

### إضافات الأداء:
5. **WP Rocket** — للتخزين المؤقت
6. **ShortPixel** — لضغط الصور

## الخطوة 3: استيراد المنتجات

1. اذهب إلى: **Tools → Import → WordPress → Run Importer**
2. ارفع ملف: `imports/herbs-milanos-products.xml`
3. اربط المنتجات بالمؤلف الحالي (admin)
4. اضغط **Import**

**النتيجة**: 47 منتجاً مع كل المواصفات الفنية سيتم إنشاؤها تلقائياً.

## الخطوة 4: رفع صور المنتجات

1. اذهب إلى: **Media → Add New**
2. ارفع جميع صور المنتجات من مجلد `product-images/`
3. لكل منتج: اذهب إلى **Products → Edit** واضبط **Featured Image**

## الخطوة 5: رفع الشهادات

1. اذهب إلى: **Media → Add New**
2. ارفع صور الشهادات من مجلد `certificates/`:
   - `iso-9001.jpg`
   - `iso-22000.jpg`
   - `haccp.jpg`

## الخطوة 6: إنشاء الصفحات

أنشئ هذه الصفحات (Pages → Add New) واختر القالب المناسب:

| الصفحة | القالب (Page Template) | المحتوى |
|---|---|---|
| **الرئيسية** | Home Page | — |
| **من نحن** | About Us | — |
| **المنتجات** | (تلقائي — CPT archive) | — |
| **دليل المصدرين** | (افتراضي) | محتوى RFQ Guide |
| **الأسئلة الشائعة** | FAQ Page | — |
| **اتصل بنا** | Contact / RFQ | — |

## الخطوة 7: إعدادات RFQ

1. اذهب إلى: **Settings → Herbs Milanos**
2. ضع البريد: `herbs.milanos.eg@gmail.com`
3. ضع واتساب: `+20 122 621 1624`
4. اضغط **Save Settings**

## الخطوة 8: إعداد WP Mail SMTP

1. اذهب إلى: **WP Mail SMTP → Settings**
2. اختر **Other SMTP** (أو Brevo/SendGrid)
3. ضع إعدادات SMTP الخاصة بك
4. اختبر الإرسال

## الخطوة 9: القوائم (Menus)

1. اذهب إلى: **Appearance → Menus**
2. أنشئ قائمة باسم "Primary Menu"
3. أضف: الرئيسية، من نحن، المنتجات، دليل المصدرين، الأسئلة الشائعة، اتصل بنا
4. اضبط **Display location** = Primary Menu

## الخطوة 10: الروابط الدائمة (Permalinks)

1. اذهب إلى: **Settings → Permalinks**
2. اختر **Post name**
3. اضغط **Save Changes**

---

## هيكل القالب

```
herbs-milanos-theme/
├── style.css              ← ستايل القالب + هوية الألوان
├── functions.php          ← CPT + ACF + RFQ handler + مساعدات
├── header.php             ← الهيدر الثابت
├── footer.php             ← الفوتر
├── index.php              ← القالب الرئيسي
├── archive-hm_product.php ← صفحة أرشيف المنتجات
├── single-hm_product.php  ← صفحة تفاصيل المنتج
├── templates/
│   ├── template-home.php       ← الصفحة الرئيسية
│   ├── template-about.php      ← من نحن
│   ├── template-products.php   ← المنتجات + فلترة
│   ├── template-faq.php        ← الأسئلة الشائعة
│   └── template-contact.php    ← نموذج RFQ
└── assets/
    ├── css/
    ├── js/main.js
    └── images/
        ├── hero-welcome.jpg    ← بانر الـ hero
        ├── about-hero.jpg
        ├── products-hero.jpg
        ├── faq-hero.jpg
        ├── contact-hero.jpg
        ├── resources-hero.jpg
        ├── iso-9001.jpg        ← شهادات ISO
        ├── iso-22000.jpg
        ├── haccp.jpg
        └── [47 صورة منتج]
```

---

## معلومات التواصل (افتراضية)
- **البريد**: herbs.milanos.eg@gmail.com (فعلي)
- **عرضه في الموقع**: info@herbsmilanos.com / export@herbsmilanos.com
- **واتساب**: +20 122 621 1624
- **العنوان**: بني سويف، مصر
- **ساعات العمل**: الاثنين – السبت، 9:00 – 17:00 (ت.م.ص.)

## الشهادات
- ISO 9001:2015 (BQSR — رقم BQSR11520)
- ISO 22000:2018 (BQSR — رقم BQSR11521)
- HACCP (BQSR — رقم BQSR11522)
