<?php
/**
 * Herbs Milanos — Custom WordPress Theme Functions
 * Version: 1.0.0
 *
 * Features:
 * - Custom Post Type: Products (with ACF spec fields)
 * - Taxonomies: Product Family, Industry
 * - i18n: Arabic (RTL) + English (LTR) via WPML/Polylang
 * - RFQ form handler
 * - REST API endpoint for products
 * - SEO: JSON-LD schema output
 */

if (!defined('ABSPATH')) exit;

define('HM_VERSION', '1.0.0');
define('HM_DIR', get_template_directory());
define('HM_URI', get_template_directory_uri());

/* ───────────────────────── 1. Theme Setup ───────────────────────── */

function hm_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption']);
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');

    // Image sizes for product catalog
    add_image_size('product-card', 600, 450, true);
    add_image_size('product-detail', 1200, 900, true);
    add_image_size('certificate', 400, 533, true);

    // Register nav menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'herbs-milanos'),
        'footer'  => __('Footer Menu', 'herbs-milanos'),
    ]);

    // Load text domain
    load_theme_textdomain('herbs-milanos', HM_DIR . '/languages');
}
add_action('after_setup_theme', 'hm_setup');

/* ───────────────────────── 2. Enqueue Assets ───────────────────────── */

function hm_scripts() {
    // Google Fonts: DM Sans + Playfair Display
    wp_enqueue_style('hm-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700;800&display=swap', [], null);

    // Theme stylesheet
    wp_enqueue_style('hm-style', get_stylesheet_uri(), ['hm-fonts'], HM_VERSION);

    // Theme JS
    wp_enqueue_script('hm-script', HM_URI . '/assets/js/main.js', [], HM_VERSION, true);

    // Pass AJAX URL + nonce to JS
    wp_localize_script('hm-script', 'hmAjax', [
        'url'   => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('hm_rfQ_nonce'),
    ]);
}
add_action('wp_enqueue_scripts', 'hm_scripts');

/* ───────────────────────── 3. Custom Post Type: Products ───────────────────────── */

function hm_register_product_cpt() {
    $labels = [
        'name'               => __('Products', 'herbs-milanos'),
        'singular_name'      => __('Product', 'herbs-milanos'),
        'menu_name'          => __('Products', 'herbs-milanos'),
        'add_new'            => __('Add New Product', 'herbs-milanos'),
        'add_new_item'       => __('Add New Product', 'herbs-milanos'),
        'edit_item'          => __('Edit Product', 'herbs-milanos'),
        'new_item'           => __('New Product', 'herbs-milanos'),
        'view_item'          => __('View Product', 'herbs-milanos'),
        'search_items'       => __('Search Products', 'herbs-milanos'),
        'not_found'          => __('No products found', 'herbs-milanos'),
    ];

    register_post_type('hm_product', [
        'labels'       => $labels,
        'public'       => true,
        'has_archive'  => true,
        'menu_icon'    => 'dashicons-products',
        'menu_position' => 5,
        'rewrite'      => ['slug' => 'products', 'with_front' => false],
        'supports'     => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
        'show_in_rest' => true, // Enable Gutenberg + REST API
    ]);
}
add_action('init', 'hm_register_product_cpt');

/* ───────────────────────── 4. Taxonomies ───────────────────────── */

function hm_register_taxonomies() {
    // Product Family
    register_taxonomy('hm_family', 'hm_product', [
        'label'        => __('Product Family', 'herbs-milanos'),
        'hierarchical' => true,
        'public'       => true,
        'show_in_rest' => true,
        'rewrite'      => ['slug' => 'product-family'],
    ]);

    // Industry / Application
    register_taxonomy('hm_industry', 'hm_product', [
        'label'        => __('Industry', 'herbs-milanos'),
        'hierarchical' => true,
        'public'       => true,
        'show_in_rest' => true,
        'rewrite'      => ['slug' => 'industry'],
    ]);
}
add_action('init', 'hm_register_taxonomies');

/* ───────────────────────── 5. ACF Fields (auto-register if ACF is active) ───────────────────────── */

function hm_register_acf_fields() {
    if (!function_exists('acf_add_local_field_group')) return;

    acf_add_local_field_group([
        'key'      => 'group_hm_product_specs',
        'title'    => 'Product Specifications',
        'fields'   => [
            ['key' => 'field_latin_name', 'label' => 'Latin Name', 'name' => 'latin_name', 'type' => 'text'],
            ['key' => 'field_brief', 'label' => 'Brief Description', 'name' => 'brief', 'type' => 'textarea', 'rows' => 2],
            ['key' => 'field_forms', 'label' => 'Available Forms', 'name' => 'forms', 'type' => 'text', 'instructions' => 'Comma-separated: Whole, Cut, TBC, Powder'],
            ['key' => 'field_grades', 'label' => 'Grades', 'name' => 'grades', 'type' => 'text', 'instructions' => 'Comma-separated: EU Conventional, Organic EC+NOP'],
            ['key' => 'field_origin', 'label' => 'Origin', 'name' => 'origin', 'type' => 'text'],
            ['key' => 'field_season', 'label' => 'Harvest Season', 'name' => 'season', 'type' => 'text'],
            ['key' => 'field_moq', 'label' => 'MOQ', 'name' => 'moq', 'type' => 'text'],
            ['key' => 'field_packing', 'label' => 'Packing', 'name' => 'packing', 'type' => 'text'],
            ['key' => 'field_purity', 'label' => 'Purity', 'name' => 'purity', 'type' => 'text'],
            ['key' => 'field_moisture', 'label' => 'Moisture', 'name' => 'moisture', 'type' => 'text'],
            ['key' => 'field_volatile_oil', 'label' => 'Volatile Oil', 'name' => 'volatile_oil', 'type' => 'text'],
            ['key' => 'field_foreign_organic', 'label' => 'Foreign Organic Matter', 'name' => 'foreign_organic', 'type' => 'text'],
            ['key' => 'field_foreign_inorganic', 'label' => 'Foreign Inorganic Matter', 'name' => 'foreign_inorganic', 'type' => 'text'],
            ['key' => 'field_shelf_life', 'label' => 'Shelf Life', 'name' => 'shelf_life', 'type' => 'text'],
            ['key' => 'field_spec_pdf', 'label' => 'Spec Sheet PDF', 'name' => 'spec_pdf', 'type' => 'file'],
        ],
        'location' => [
            [['param' => 'post_type', 'operator' => '==', 'value' => 'hm_product']],
        ],
    ]);
}
add_action('acf/init', 'hm_register_acf_fields');

/* ───────────────────────── 6. RFQ Form Handler ───────────────────────── */

function hm_handle_rfq() {
    check_ajax_referer('hm_rfQ_nonce', 'nonce');

    $to = get_option('hm_export_email', 'herbs.milanos.eg@gmail.com');
    $subject = 'New RFQ from ' . sanitize_text_field($_POST['name'] ?? '');

    $body = "New RFQ submission:\n\n";
    $fields = ['name', 'company', 'country', 'email', 'phone', 'category', 'product', 'quantity', 'form', 'packing', 'port', 'incoterm', 'notes'];
    foreach ($fields as $f) {
        $body .= ucfirst($f) . ': ' . sanitize_text_field($_POST[$f] ?? '') . "\n";
    }

    $headers = ['Reply-To: ' . sanitize_email($_POST['email'] ?? '')];

    wp_mail($to, $subject, $body, $headers);

    // Auto-responder to customer
    $customer_email = sanitize_email($_POST['email'] ?? '');
    if ($customer_email) {
        $auto_subject = 'RFQ Received — Herbs Milanos';
        $auto_body = "Thank you for contacting Herbs Milanos.\n\nWe received your RFQ and will reply within 24 business hours.\n\nWhatsApp: +20 122 621 1624\nEmail: export@herbsmilanos.com";
        wp_mail($customer_email, $auto_subject, $auto_body);
    }

    wp_send_json_success(['message' => 'Thank you. Our export team will reply within 24 business hours.']);
}
add_action('wp_ajax_hm_rfq', 'hm_handle_rfq');
add_action('wp_ajax_nopriv_hm_rfq', 'hm_handle_rfq');

/* ───────────────────────── 7. Settings Page ───────────────────────── */

function hm_settings_page() {
    add_options_page('Herbs Milanos Settings', 'Herbs Milanos', 'manage_options', 'hm-settings', 'hm_settings_html');
}
add_action('admin_menu', 'hm_settings_page');

function hm_settings_html() {
    if (isset($_POST['hm_save_settings'])) {
        update_option('hm_export_email', sanitize_email($_POST['export_email']));
        update_option('hm_whatsapp', sanitize_text_field($_POST['whatsapp']));
        update_option('hm_phone', sanitize_text_field($_POST['phone']));
        echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    }
    $export_email = get_option('hm_export_email', 'herbs.milanos.eg@gmail.com');
    $whatsapp = get_option('hm_whatsapp', '+20 122 621 1624');
    $phone = get_option('hm_phone', '+20 122 621 1624');
    ?>
    <div class="wrap">
        <h1>Herbs Milanos Settings</h1>
        <form method="post">
            <table class="form-table">
                <tr><th>Export Email (RFQ recipient)</th><td><input type="email" name="export_email" value="<?php echo esc_attr($export_email); ?>" class="regular-text"></td></tr>
                <tr><th>WhatsApp Number</th><td><input type="text" name="whatsapp" value="<?php echo esc_attr($whatsapp); ?>" class="regular-text"></td></tr>
                <tr><th>Phone Number</th><td><input type="text" name="phone" value="<?php echo esc_attr($phone); ?>" class="regular-text"></td></tr>
            </table>
            <p class="submit"><button type="submit" name="hm_save_settings" class="button button-primary">Save Settings</button></p>
        </form>
    </div>
    <?php
}

/* ───────────────────────── 8. Helper Functions ───────────────────────── */

function hm_get_products($limit = -1, $family = '') {
    $args = [
        'post_type'      => 'hm_product',
        'posts_per_page' => $limit,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
    ];
    if ($family) {
        $args['tax_query'] = [['taxonomy' => 'hm_family', 'field' => 'slug', 'terms' => $family]];
    }
    return get_posts($args);
}

function hm_get_certifications() {
    return [
        ['name' => 'ISO 9001:2015', 'desc' => 'Quality Management System', 'image' => HM_URI . '/assets/images/iso-9001.jpg'],
        ['name' => 'ISO 22000:2018', 'desc' => 'Food Safety Management System', 'image' => HM_URI . '/assets/images/iso-22000.jpg'],
        ['name' => 'HACCP', 'desc' => 'Hazard Analysis & Critical Control Points', 'image' => HM_URI . '/assets/images/haccp.jpg'],
    ];
}

function hm_get_faq() {
    return [
        'about' => ['title' => 'About Herbs Milanos', 'items' => [
            ['q' => 'Who are you?', 'a' => 'We are Herbs Milanos — an Egyptian exporter of herbs, spices, seeds and aromatic plants since 2000.'],
            ['q' => 'Are you a manufacturer or a trader?', 'a' => 'Both. We process and pack products in our own facilities, and source from farms across Egypt.'],
            ['q' => 'Why source herbs from Egypt?', 'a' => 'Egypt is an important origin for chamomile, basil, marjoram, mint, cumin, coriander, fennel, anise, hibiscus and more.'],
        ]],
        'products' => ['title' => 'Products & Specifications', 'items' => [
            ['q' => 'What products do you export?', 'a' => 'Dried herbs, flowers, seeds, spices, medicinal and aromatic plants.'],
            ['q' => 'What cuts and forms are available?', 'a' => 'Whole, crushed, cut, TBC, sifted, rubbed, or powdered. Custom cuts on request.'],
            ['q' => 'Are your products organic?', 'a' => 'Conventional products available. Certified organic on request — please confirm before ordering.'],
            ['q' => 'Can you meet EU pesticide (MRL) requirements?', 'a' => 'Yes. We comply with global food-safety standards. Pesticide testing against your market requirements.'],
            ['q' => 'Are your herbs sterilized or treated?', 'a' => 'Steam sterilization available where feasible. Please specify your requirements.'],
        ]],
        'quality' => ['title' => 'Quality & Certifications', 'items' => [
            ['q' => 'What certifications do you have?', 'a' => 'ISO 9001:2015, ISO 22000:2018, and HACCP. Certificates available on request.'],
            ['q' => 'Can I get a sample before ordering?', 'a' => 'Yes. Our team will confirm sample quantity, cost, and courier charges.'],
            ['q' => 'Can I use third-party inspection?', 'a' => 'Yes, third-party inspection can be arranged. Please advise your preferred agency, scope and timing.'],
        ]],
        'orders' => ['title' => 'Orders & Pricing', 'items' => [
            ['q' => 'What is your MOQ?', 'a' => 'Typically 1 metric ton per product. Mixed 20ft container accepted.'],
            ['q' => 'Can I mix products in one container?', 'a' => 'Yes, mixed-container orders possible where compatibility allows.'],
            ['q' => 'What are your payment terms?', 'a' => '30% advance (T/T) + 70% against shipping documents. L/C at sight for large orders.'],
        ]],
        'shipping' => ['title' => 'Shipping & Documents', 'items' => [
            ['q' => 'Which ports do you ship from?', 'a' => 'Alexandria, Port Said, and Damietta.'],
            ['q' => 'How long does it take to prepare an order?', 'a' => '2–4 weeks after confirmation and payment.'],
            ['q' => 'What documents do you provide?', 'a' => 'Commercial Invoice, Packing List, Certificate of Origin, Phytosanitary Certificate, COA.'],
            ['q' => 'Can you ship to my country?', 'a' => 'Send us your destination country and port so we can check shipping possibilities.'],
        ]],
        'contact' => ['title' => 'Contact', 'items' => [
            ['q' => 'How can I request a quotation?', 'a' => 'Via the contact form, email export@herbsmilanos.com, or WhatsApp +20 122 621 1624.'],
        ]],
    ];
}

/* ───────────────────────── 9. JSON-LD Schema ───────────────────────── */

function hm_output_schema() {
    if (is_singular('hm_product')) {
        $product = get_queried_object();
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => get_the_title($product),
            'description' => get_field('brief', $product->ID) ?: get_the_excerpt($product),
            'brand' => ['@type' => 'Brand', 'name' => 'Herbs Milanos'],
            'sku' => $product->post_name,
        ];
        echo '<script type="application/ld+json">' . json_encode($schema) . '</script>';
    }
}
add_action('wp_head', 'hm_output_schema');

/* ───────────────────────── 10. RTL Detection ───────────────────────── */

function hm_body_class($classes) {
    $locale = get_locale();
    if (strpos($locale, 'ar') === 0 || strpos($locale, 'he') === 0 || strpos($locale, 'fa') === 0) {
        $classes[] = 'rtl';
    }
    return $classes;
}
add_filter('body_class', 'hm_body_class');

function hm_html_dir($output) {
    $locale = get_locale();
    if (strpos($locale, 'ar') === 0) {
        return 'dir="rtl" lang="ar"';
    }
    return $output;
}
add_filter('language_attributes', 'hm_html_dir');
