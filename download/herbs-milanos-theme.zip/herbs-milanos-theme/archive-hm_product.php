<?php
/**
 * Archive: Products
 * Uses the products template
 */
include('templates/template-products.php');
