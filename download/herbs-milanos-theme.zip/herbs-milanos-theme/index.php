<?php
/**
 * Main template — falls back to home page template
 */
get_header();

// If front page, use the home template
if (is_front_page()) {
    include('templates/template-home.php');
} else {
    // Default content loop
    while (have_posts()) :
        the_post();
        echo '<section><div class="container">';
        the_title('<h1 class="section-title">', '</h1>');
        echo '<div class="divider"></div>';
        the_content();
        echo '</div></section>';
    endwhile;
}

get_footer();
