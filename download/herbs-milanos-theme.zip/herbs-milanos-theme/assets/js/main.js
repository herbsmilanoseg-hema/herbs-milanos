// Herbs Milanos — Theme JS
// Version 1.0.0

document.addEventListener('DOMContentLoaded', function() {
    // FAQ Accordion
    document.querySelectorAll('.faq-question').forEach(function(q) {
        q.addEventListener('click', function() {
            var item = this.parentElement;
            var wasOpen = item.classList.contains('open');
            document.querySelectorAll('.faq-item').forEach(function(i) {
                i.classList.remove('open');
            });
            if (!wasOpen) item.classList.add('open');
        });
    });

    // Product search filter
    var search = document.getElementById('product-search');
    if (search) {
        var cards = document.querySelectorAll('#product-grid .product-card');
        var countEl = document.getElementById('product-count');
        search.addEventListener('input', function() {
            var q = this.value.toLowerCase();
            var visible = 0;
            cards.forEach(function(card) {
                var name = card.getAttribute('data-name') || '';
                var match = name.indexOf(q) !== -1;
                card.style.display = match ? '' : 'none';
                if (match) visible++;
            });
            if (countEl) countEl.textContent = visible + ' منتج';
        });
    }

    // Header scroll shadow
    var header = document.querySelector('.site-header');
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 8) {
                header.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
            } else {
                header.style.boxShadow = '0 1px 3px rgba(0,0,0,0.05)';
            }
        });
    }
});
