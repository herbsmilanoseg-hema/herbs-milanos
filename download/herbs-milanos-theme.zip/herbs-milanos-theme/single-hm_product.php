<?php
/**
 * Single Product
 */
include('templates/template-single-product.php');
