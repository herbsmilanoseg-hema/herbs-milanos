<?php
/**
 * Template Name: Contact / RFQ Page
 */
get_header();
?>

<section class="hero" style="min-height:40vh;">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/contact-hero.jpg" alt="Contact us">
    <div class="hero-content" style="padding-top:2rem;">
        <span class="hero-badge"><?php _e('اتصل بنا / طلب عرض سعر', 'herbs-milanos'); ?></span>
        <h1 style="font-size:clamp(1.5rem,4vw,2.5rem);"><?php _e('نحن هنا لبناء شراكة تجارية ناجحة معك', 'herbs-milanos'); ?></h1>
        <p style="margin-top:1rem;max-width:42rem;"><?php _e('فريق المبيعات والتصدير لدينا جاهز للرد على استفساراتك وتقديم عروض أسعار مخصصة.', 'herbs-milanos'); ?></p>
    </div>
</section>

<section>
    <div class="container" style="display:grid;grid-template-columns:1fr 1.3fr;gap:2rem;">
        <!-- Contact info -->
        <div style="display:flex;flex-direction:column;gap:0.75rem;">
            <div class="card" style="padding:1rem;display:flex;align-items:center;gap:1rem;">
                <span style="font-size:1.25rem;">📍</span>
                <div>
                    <p style="font-size:0.7rem;text-transform:uppercase;color:rgba(37,51,40,0.5);"><?php _e('المقر', 'herbs-milanos'); ?></p>
                    <p style="font-weight:600;">بني سويف، مصر</p>
                </div>
            </div>
            <div class="card" style="padding:1rem;display:flex;align-items:center;gap:1rem;">
                <span style="font-size:1.25rem;">💬</span>
                <div>
                    <p style="font-size:0.7rem;text-transform:uppercase;color:rgba(37,51,40,0.5);">WhatsApp</p>
                    <a href="https://wa.me/201226211624" target="_blank" style="font-weight:600;">+20 122 621 1624</a>
                </div>
            </div>
            <div class="card" style="padding:1rem;display:flex;align-items:center;gap:1rem;">
                <span style="font-size:1.25rem;">📧</span>
                <div>
                    <p style="font-size:0.7rem;text-transform:uppercase;color:rgba(37,51,40,0.5);"><?php _e('بريد التصدير', 'herbs-milanos'); ?></p>
                    <a href="mailto:export@herbsmilanos.com" style="font-weight:600;">export@herbsmilanos.com</a>
                </div>
            </div>
            <div class="card" style="padding:1rem;display:flex;align-items:center;gap:1rem;">
                <span style="font-size:1.25rem;">🕐</span>
                <div>
                    <p style="font-size:0.7rem;text-transform:uppercase;color:rgba(37,51,40,0.5);"><?php _e('ساعات العمل', 'herbs-milanos'); ?></p>
                    <p style="font-weight:600;"><?php _e('الاثنين – السبت، 9:00 – 17:00 (ت.م.ص.)', 'herbs-milanos'); ?></p>
                </div>
            </div>
        </div>

        <!-- RFQ Form -->
        <form class="contact-form" id="rfq-form">
            <div class="form-row">
                <div><label><?php _e('الاسم الكامل *', 'herbs-milanos'); ?></label><input type="text" name="name" required></div>
                <div><label><?php _e('اسم الشركة *', 'herbs-milanos'); ?></label><input type="text" name="company" required></div>
            </div>
            <div class="form-row">
                <div><label><?php _e('الدولة *', 'herbs-milanos'); ?></label><input type="text" name="country" required></div>
                <div><label><?php _e('البريد الإلكتروني *', 'herbs-milanos'); ?></label><input type="email" name="email" required></div>
            </div>
            <div class="form-row">
                <div><label><?php _e('رقم الهاتف / واتساب', 'herbs-milanos'); ?></label><input type="text" name="phone"></div>
                <div><label><?php _e('فئة المنتج', 'herbs-milanos'); ?></label>
                    <select name="category"><option value="">—</option><option>أعشاب</option><option>توابل</option><option>بذور</option><option>أزهار</option></select>
                </div>
            </div>
            <div class="form-row">
                <div><label><?php _e('المنتج المحدد', 'herbs-milanos'); ?></label><input type="text" name="product"></div>
                <div><label><?php _e('الكمية المتوقعة', 'herbs-milanos'); ?></label><input type="text" name="quantity" placeholder="e.g. 5 MT"></div>
            </div>
            <div class="form-row">
                <div><label><?php _e('ميناء الوصول', 'herbs-milanos'); ?></label><input type="text" name="port"></div>
                <div><label><?php _e('شروط التسليم', 'herbs-milanos'); ?></label>
                    <select name="incoterm"><option value="">—</option><option>FOB</option><option>CIF</option><option>CFR</option><option>EXW</option></select>
                </div>
            </div>
            <div style="margin-bottom:1rem;"><label><?php _e('ملاحظات', 'herbs-milanos'); ?></label><textarea name="notes" rows="4"></textarea></div>
            <button type="submit" class="btn btn-primary" style="width:100%;"><?php _e('إرسال طلب عرض السعر', 'herbs-milanos'); ?></button>
            <div id="rfq-status" style="margin-top:1rem;display:none;padding:1rem;border-radius:0.5rem;background:rgba(149,184,88,0.15);color:var(--primary);font-weight:600;"></div>
        </form>
    </div>
</section>

<script>
document.getElementById('rfq-form').addEventListener('submit', function(e) {
    e.preventDefault();
    var form = this;
    var data = new FormData(form);
    data.append('action', 'hm_rfq');
    data.append('nonce', hmAjax.nonce);
    var btn = form.querySelector('button[type=submit]');
    btn.textContent = 'جارٍ الإرسال…';
    btn.disabled = true;
    fetch(hmAjax.url, { method: 'POST', body: data })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            var status = document.getElementById('rfq-status');
            status.style.display = 'block';
            status.textContent = res.data.message;
            form.reset();
        })
        .catch(function() {
            var status = document.getElementById('rfq-status');
            status.style.display = 'block';
            status.textContent = 'شكراً لطلبك. سنرد خلال 24 ساعة عمل.';
        })
        .finally(function() {
            btn.textContent = 'إرسال طلب عرض السعر';
            btn.disabled = false;
        });
});
</script>

<?php get_footer(); ?>
