<?php
/**
 * Template Name: FAQ Page
 */
get_header();
$faq = hm_get_faq();
?>

<section class="hero" style="min-height:40vh;">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/faq-hero.jpg" alt="FAQ">
    <div class="hero-content" style="padding-top:2rem;">
        <span class="hero-badge">B2B FAQ</span>
        <h1 style="font-size:clamp(1.5rem,4vw,2.5rem);"><?php _e('كل ما يسأل عنه المشترون الدوليون', 'herbs-milanos'); ?></h1>
        <p style="margin-top:1rem;max-width:42rem;"><?php _e('إجابات واضحة وشاملة على أكثر الأسئلة شيوعاً حول شركتنا، منتجاتنا، الجودة، الطلبات، التعبئة، الشحن، التخزين والتواصل.', 'herbs-milanos'); ?></p>
    </div>
</section>

<section>
    <div class="container" style="max-width:48rem;">
        <?php foreach ($faq as $cat_id => $cat): ?>
            <div class="faq-category">
                <h2 style="font-size:1.5rem;margin-bottom:1rem;"><?php echo esc_html($cat['title']); ?></h2>
                <div class="divider"></div>
                <?php foreach ($cat['items'] as $item): ?>
                    <div class="faq-item">
                        <div class="faq-question"><?php echo esc_html($item['q']); ?></div>
                        <div class="faq-answer"><p style="padding-top:0.5rem;"><?php echo esc_html($item['a']); ?></p></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<script>
document.querySelectorAll('.faq-question').forEach(function(q) {
    q.addEventListener('click', function() {
        var item = this.parentElement;
        var wasOpen = item.classList.contains('open');
        // Close all
        document.querySelectorAll('.faq-item').forEach(function(i) { i.classList.remove('open'); });
        // Toggle current
        if (!wasOpen) item.classList.add('open');
    });
});
</script>

<?php get_footer(); ?>
