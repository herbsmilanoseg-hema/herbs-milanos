<?php
/**
 * Template Name: Home Page
 */
get_header();
?>

<!-- Hero -->
<section class="hero">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero-welcome.jpg" alt="Herbs Milanos — Egyptian botanicals export">
    <div class="hero-content">
        <span class="hero-badge">🌿 Herbs Milanos · Exporting Egyptian Botanicals since 2000</span>
        <h1><?php echo __('من مزارع مصر العضوية إلى أسواق العالم.. جودة لا تُقاوم', 'herbs-milanos'); ?></h1>
        <p><?php echo __('شريكك الموثوق في زراعة ومعالجة وتصدير الأعشاب والتوابل والبذور المصرية بأعلى معايير الجودة العالمية وشهادات ISO و HACCP.', 'herbs-milanos'); ?></p>
        <div class="hero-cta">
            <a href="/contact" class="btn btn-primary"><?php _e('اطلب عرض سعر الآن', 'herbs-milanos'); ?> →</a>
            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/catalogue.pdf" class="btn btn-outline" style="color:#fff;border-color:rgba(255,255,255,0.4)"><?php _e('حمّل كتالوج المنتجات', 'herbs-milanos'); ?> ↓</a>
        </div>
        <div class="hero-trust">
            <span class="badge">📦 MOQ from 1 MT</span>
            <span class="badge">🚢 FOB · CIF · CFR</span>
            <span class="badge">🛡️ ISO 22000 · HACCP</span>
            <span class="badge">🌿 100+ SKUs</span>
        </div>
    </div>
</section>

<!-- Why Choose Us -->
<section>
    <div class="container">
        <div class="text-center">
            <p class="section-eyebrow"><?php _e('لماذا تختار هيربز ميلانو؟', 'herbs-milanos'); ?></p>
            <h2 class="section-title"><?php _e('شريك تصدير مبني على الثقة والجودة.', 'herbs-milanos'); ?></h2>
            <div class="divider"></div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1.5rem;margin-top:3rem;">
            <div class="card" style="padding:1.5rem;">
                <h3><?php _e('تحكم كامل في سلسلة الإمداد', 'herbs-milanos'); ?></h3>
                <p style="color:rgba(37,51,40,0.65);font-size:0.9rem;margin-top:0.5rem;"><?php _e('نمتلك مزارعنا الخاصة في بني سويف، مما يضمن السيطرة على الجودة من الزراعة حتى التغليف.', 'herbs-milanos'); ?></p>
            </div>
            <div class="card" style="padding:1.5rem;">
                <h3><?php _e('معايير جودة عالمية', 'herbs-milanos'); ?></h3>
                <p style="color:rgba(37,51,40,0.65);font-size:0.9rem;margin-top:0.5rem;"><?php _e('فرز مغناطيسي متقدم، وفحوصات مخبرية دقيقة لضمان نقاء المنتج وخلوه من الشوائب.', 'herbs-milanos'); ?></p>
            </div>
            <div class="card" style="padding:1.5rem;">
                <h3><?php _e('شراكات عالمية موثوقة', 'herbs-milanos'); ?></h3>
                <p style="color:rgba(37,51,40,0.65);font-size:0.9rem;margin-top:0.5rem;"><?php _e('نفخر بتوريد منتجاتنا لشركات كبرى في الاتحاد الأوروبي والولايات المتحدة وروسيا ودول الخليج منذ أكثر من 15 عاماً.', 'herbs-milanos'); ?></p>
            </div>
        </div>
    </div>
</section>

<!-- Featured Products -->
<section class="alt">
    <div class="container">
        <div class="text-center">
            <p class="section-eyebrow"><?php _e('منتجاتنا', 'herbs-milanos'); ?></p>
            <h2 class="section-title"><?php _e('انعكاس لجودة الأرض المصرية ودقة المعايير العالمية', 'herbs-milanos'); ?></h2>
            <div class="divider"></div>
            <p class="section-intro"><?php _e('نقدم مجموعة شاملة من الأعشاب المجففة والتوابل والبذور، المزروعة بعناية ومعالجة بأحدث التقنيات.', 'herbs-milanos'); ?></p>
        </div>
        <div class="product-grid" style="margin-top:3rem;">
            <?php
            $products = hm_get_products(6);
            foreach ($products as $p):
                $img = get_the_post_thumbnail_url($p->ID, 'product-card') ?: get_template_directory_uri() . '/assets/images/product-placeholder.jpg';
            ?>
                <a href="<?php echo get_permalink($p->ID); ?>" class="product-card">
                    <img src="<?php echo $img; ?>" alt="<?php echo esc_attr($p->post_title); ?>">
                    <div class="product-card-body">
                        <h3><?php echo esc_html($p->post_title); ?></h3>
                        <p class="latin"><?php echo esc_html(get_field('latin_name', $p->ID)); ?></p>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
        <div class="text-center" style="margin-top:2.5rem;">
            <a href="/products" class="btn btn-primary"><?php _e('عرض كل المنتجات', 'herbs-milanos'); ?> →</a>
        </div>
    </div>
</section>

<!-- Certifications -->
<section>
    <div class="container">
        <div class="text-center">
            <p class="section-eyebrow">🛡️ <?php _e('شهاداتنا واعتماداتنا', 'herbs-milanos'); ?></p>
            <h2 class="section-title">ISO 9001:2015 · ISO 22000:2018 · HACCP</h2>
            <div class="divider"></div>
            <p class="section-intro"><?php _e('نلتزم بأعلى معايير سلامة الغذاء والصحة العالمية في كل شحنة نصدّرها.', 'herbs-milanos'); ?></p>
        </div>
        <div class="cert-grid" style="margin-top:3rem;">
            <?php foreach (hm_get_certifications() as $cert): ?>
                <div class="cert-card">
                    <img src="<?php echo $cert['image']; ?>" alt="<?php echo esc_attr($cert['name']); ?> certificate">
                    <div class="cert-card-body">
                        <h3><?php echo esc_html($cert['name']); ?></h3>
                        <p style="font-size:0.75rem;color:rgba(37,51,40,0.5);"><?php echo esc_html($cert['desc']); ?></p>
                        <a href="<?php echo $cert['image']; ?>" download class="btn btn-outline" style="margin-top:0.75rem;width:100%;justify-content:center;font-size:0.8rem;">
                            <?php _e('تحميل الشهادة', 'herbs-milanos'); ?> ↓
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>
