<?php
/**
 * Single Product Template
 */
get_header();
$product = get_queried_object();
$latin = get_field('latin_name', $product->ID);
$brief = get_field('brief', $product->ID);
$forms = array_filter(explode(',', get_field('forms', $product->ID)));
$grades = array_filter(explode(',', get_field('grades', $product->ID)));
$origin = get_field('origin', $product->ID);
$season = get_field('season', $product->ID);
$moq = get_field('moq', $product->ID);
$packing = get_field('packing', $product->ID);
$purity = get_field('purity', $product->ID);
$moisture = get_field('moisture', $product->ID);
$volatile_oil = get_field('volatile_oil', $product->ID);
$foreign_organic = get_field('foreign_organic', $product->ID);
$foreign_inorganic = get_field('foreign_inorganic', $product->ID);
$shelf_life = get_field('shelf_life', $product->ID);
$img = get_the_post_thumbnail_url($product->ID, 'product-detail') ?: get_template_directory_uri() . '/assets/images/product-placeholder.jpg';
?>

<!-- Breadcrumb -->
<div class="container" style="padding-top:1.5rem;">
    <a href="/products" style="font-size:0.875rem;color:rgba(37,51,40,0.5);">← <?php _e('العودة إلى المنتجات', 'herbs-milanos'); ?></a>
</div>

<section style="padding-top:2rem;">
    <div class="container" style="display:grid;grid-template-columns:1fr 1fr;gap:2.5rem;">
        <!-- Image -->
        <div>
            <img src="<?php echo $img; ?>" alt="<?php echo esc_attr($product->post_title); ?>" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:1rem;box-shadow:0 4px 12px rgba(0,0,0,0.1);">
        </div>

        <!-- Info -->
        <div>
            <h1 style="font-size:2rem;"><?php echo esc_html($product->post_title); ?></h1>
            <p style="font-style:italic;color:rgba(37,51,40,0.5);"><?php echo esc_html($latin); ?></p>
            <div class="divider"></div>
            <p style="color:rgba(37,51,40,0.65);margin-bottom:1.5rem;"><?php echo esc_html($brief); ?></p>

            <!-- Key facts -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1.5rem;">
                <div style="border:1px solid rgba(23,76,53,0.1);border-radius:0.75rem;padding:1rem;">
                    <p style="font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;color:rgba(37,51,40,0.5);">Origin</p>
                    <p style="font-weight:600;"><?php echo esc_html($origin); ?></p>
                </div>
                <div style="border:1px solid rgba(23,76,53,0.1);border-radius:0.75rem;padding:1rem;">
                    <p style="font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;color:rgba(37,51,40,0.5);">Season</p>
                    <p style="font-weight:600;"><?php echo esc_html($season); ?></p>
                </div>
                <div style="border:1px solid rgba(23,76,53,0.1);border-radius:0.75rem;padding:1rem;">
                    <p style="font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;color:rgba(37,51,40,0.5);">MOQ</p>
                    <p style="font-weight:600;"><?php echo esc_html($moq); ?></p>
                </div>
                <div style="border:1px solid rgba(23,76,53,0.1);border-radius:0.75rem;padding:1rem;">
                    <p style="font-size:0.7rem;text-transform:uppercase;letter-spacing:0.1em;color:rgba(37,51,40,0.5);">Purity</p>
                    <p style="font-weight:600;"><?php echo esc_html($purity); ?></p>
                </div>
            </div>

            <!-- CTA buttons -->
            <div style="display:flex;gap:0.75rem;flex-wrap:wrap;">
                <a href="/contact?product=<?php echo $product->post_name; ?>&intent=quote" class="btn btn-primary"><?php _e('طلب عرض سعر مخصص', 'herbs-milanos'); ?></a>
                <a href="/contact?product=<?php echo $product->post_name; ?>&intent=sample" class="btn btn-outline"><?php _e('طلب عينة', 'herbs-milanos'); ?></a>
            </div>
        </div>
    </div>

    <!-- Spec Table -->
    <div class="container" style="margin-top:4rem;display:grid;grid-template-columns:1fr 1fr;gap:2rem;">
        <div>
            <h3 style="margin-bottom:1rem;"><?php _e('المواصفات الفنية والتحليلية', 'herbs-milanos'); ?></h3>
            <table class="spec-table">
                <tr><th>Purity</th><td><?php echo esc_html($purity); ?></td></tr>
                <tr><th>Moisture</th><td><?php echo esc_html($moisture); ?></td></tr>
                <tr><th>Volatile Oil</th><td><?php echo esc_html($volatile_oil); ?></td></tr>
                <tr><th>Foreign Organic</th><td><?php echo esc_html($foreign_organic); ?></td></tr>
                <tr><th>Foreign Inorganic</th><td><?php echo esc_html($foreign_inorganic); ?></td></tr>
                <tr><th>Shelf Life</th><td><?php echo esc_html($shelf_life); ?></td></tr>
            </table>
        </div>
        <div>
            <h3 style="margin-bottom:1rem;"><?php _e('أشكال متاحة + التعبئة', 'herbs-milanos'); ?></h3>
            <div style="display:flex;flex-wrap:wrap;gap:0.5rem;margin-bottom:1rem;">
                <?php foreach ($forms as $f): ?>
                    <span style="border:1px solid rgba(23,76,53,0.3);background:rgba(23,76,53,0.05);color:var(--primary);padding:0.3rem 0.6rem;border-radius:0.5rem;font-size:0.85rem;font-weight:500;"><?php echo esc_html(trim($f)); ?></span>
                <?php endforeach; ?>
            </div>
            <p style="font-size:0.9rem;color:rgba(37,51,40,0.65);"><?php echo esc_html($packing); ?></p>
            <p style="font-size:0.9rem;color:rgba(37,51,40,0.65);margin-top:0.5rem;"><strong>Shelf Life:</strong> <?php echo esc_html($shelf_life); ?></p>

            <div style="margin-top:1.5rem;">
                <h4 style="font-size:0.85rem;color:var(--primary);margin-bottom:0.5rem;"><?php _e('الاعتمادات', 'herbs-milanos'); ?></h4>
                <p style="font-size:0.85rem;">✅ COA · ✅ Phytosanitary · ✅ Certificate of Origin · ✅ HACCP & ISO 22000</p>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
