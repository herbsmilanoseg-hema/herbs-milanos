<?php
/**
 * Template Name: About Us
 */
get_header();
?>

<section class="hero" style="min-height:45vh;">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/about-hero.jpg" alt="About Herbs Milanos">
    <div class="hero-content" style="padding-top:2rem;">
        <h1 style="font-size:clamp(1.5rem,4vw,2.5rem);"><?php _e('جذورنا في الأرض المصرية.. ورؤيتنا في كل أنحاء العالم', 'herbs-milanos'); ?></h1>
    </div>
</section>

<section>
    <div class="container" style="max-width:48rem;">
        <h2 class="section-title"><?php _e('قصتنا وتطورنا', 'herbs-milanos'); ?></h2>
        <div class="divider"></div>
        <p style="color:rgba(37,51,40,0.65);margin-top:1.5rem;">
            <?php _e('بدأت رحلتنا كمورّد موثوق في السوق المحلي لأكثر من عشر سنوات، حيث اكتسبنا خبرة عميقة في معالجة وتنظيف المواد الخام. ثم جاءت بداية التصدير، تحت اسم «هيربز ميلانو».', 'herbs-milanos'); ?>
        </p>
        <p style="color:rgba(37,51,40,0.65);margin-top:1rem;">
            <?php _e('اليوم، نحن نعد واحدة من أكبر شركات تصدير الأعشاب والتوابل في مصر، مدفوعين بهدف واحد: رضا العميل من خلال الجودة، والسعر التنافسي، والالتزام الصارم بمواعيد التسليم.', 'herbs-milanos'); ?>
        </p>
    </div>
</section>

<section class="alt">
    <div class="container">
        <h2 class="section-title"><?php _e('مزارعنا وعمليات الإنتاج', 'herbs-milanos'); ?></h2>
        <div class="divider"></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1.5rem;margin-top:2rem;">
            <div class="card" style="padding:1.5rem;">
                <h3 style="font-size:1.1rem;"><?php _e('1. الزراعة والحصاد', 'herbs-milanos'); ?></h3>
                <p style="font-size:0.85rem;color:rgba(37,51,40,0.65);margin-top:0.5rem;"><?php _e('باستخدام ممارسات زراعية مستدامة واختيار أفضل البذور.', 'herbs-milanos'); ?></p>
            </div>
            <div class="card" style="padding:1.5rem;">
                <h3 style="font-size:1.1rem;"><?php _e('2. التجفيف والمعالجة', 'herbs-milanos'); ?></h3>
                <p style="font-size:0.85rem;color:rgba(37,51,40,0.65);margin-top:0.5rem;"><?php _e('بتقنيات تحافظ على الألوان الطبيعية ومحتوى الزيوت الطيارة العالي.', 'herbs-milanos'); ?></p>
            </div>
            <div class="card" style="padding:1.5rem;">
                <h3 style="font-size:1.1rem;"><?php _e('3. الفرز والتنظيف', 'herbs-milanos'); ?></h3>
                <p style="font-size:0.85rem;color:rgba(37,51,40,0.65);margin-top:0.5rem;"><?php _e('تقنيات متطورة بما في ذلك أجهزة الفرز المغناطيسي (Iron Picking Magnets).', 'herbs-milanos'); ?></p>
            </div>
            <div class="card" style="padding:1.5rem;">
                <h3 style="font-size:1.1rem;"><?php _e('4. التغليف والتصدير', 'herbs-milanos'); ?></h3>
                <p style="font-size:0.85rem;color:rgba(37,51,40,0.65);margin-top:0.5rem;"><?php _e('تعبئة آمنة تحافظ على طزاجة المنتج حتى وصوله لوجهته النهائية.', 'herbs-milanos'); ?></p>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container" style="max-width:48rem;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:2rem;">
            <div class="card" style="padding:2rem;">
                <h3><?php _e('رؤيتنا', 'herbs-milanos'); ?></h3>
                <p style="color:rgba(37,51,40,0.65);margin-top:0.75rem;"><?php _e('أن نكون الشريك الأول والأكثر موثوقية في سوق الأعشاب والتوابل عالمياً.', 'herbs-milanos'); ?></p>
            </div>
            <div class="card" style="padding:2rem;">
                <h3><?php _e('رسالتنا', 'herbs-milanos'); ?></h3>
                <p style="color:rgba(37,51,40,0.65);margin-top:0.75rem;"><?php _e('تقديم منتجات زراعية مصرية استثنائية، مدعومة بشفافية كاملة، وتحاليل جودة دقيقة، وخدمة ما بعد البيع تلبي أعلى التوقعات.', 'herbs-milanos'); ?></p>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
