<?php
/**
 * Template Name: Products Archive
 */
get_header();
?>

<!-- Hero -->
<section class="hero" style="min-height:45vh;">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/products-hero.jpg" alt="Egyptian seeds and spices">
    <div class="hero-content" style="padding-top:2rem;">
        <span class="hero-badge"><?php _e('منتجاتنا', 'herbs-milanos'); ?></span>
        <h1 style="font-size:clamp(1.5rem,4vw,2.5rem);"><?php _e('انعكاس لجودة الأرض المصرية ودقة المعايير العالمية', 'herbs-milanos'); ?></h1>
    </div>
</section>

<!-- Products with filter -->
<section>
    <div class="container" style="display:grid;grid-template-columns:260px 1fr;gap:2rem;">
        <!-- Filter Sidebar -->
        <aside class="filter-sidebar">
            <h4 style="font-size:0.75rem;text-transform:uppercase;letter-spacing:0.1em;color:rgba(37,51,40,0.5);margin-bottom:1rem;"><?php _e('بحث', 'herbs-milanos'); ?></h4>
            <input type="text" id="product-search" placeholder="<?php _e('ابحث عن منتج…', 'herbs-milanos'); ?>" style="width:100%;padding:0.5rem;border:1px solid rgba(23,76,53,0.2);border-radius:0.375rem;font-size:0.875rem;">

            <div class="filter-group">
                <h4><?php _e('فئة المنتج', 'herbs-milanos'); ?></h4>
                <?php
                $families = get_terms(['taxonomy' => 'hm_family', 'hide_empty' => false]);
                foreach ($families as $fam): ?>
                    <label><input type="checkbox" class="filter-family" value="<?php echo $fam->slug; ?>"> <?php echo esc_html($fam->name); ?></label>
                <?php endforeach; ?>
            </div>

            <div class="filter-group">
                <h4><?php _e('التطبيق', 'herbs-milanos'); ?></h4>
                <?php
                $industries = get_terms(['taxonomy' => 'hm_industry', 'hide_empty' => false]);
                foreach ($industries as $ind): ?>
                    <label><input type="checkbox" class="filter-industry" value="<?php echo $ind->slug; ?>"> <?php echo esc_html($ind->name); ?></label>
                <?php endforeach; ?>
            </div>
        </aside>

        <!-- Product Grid -->
        <div>
            <p style="font-size:0.875rem;color:rgba(37,51,40,0.5);margin-bottom:1rem;" id="product-count">
                <?php
                $all_products = hm_get_products();
                echo count($all_products) . ' ' . __('منتج', 'herbs-milanos');
                ?>
            </p>
            <div class="product-grid" id="product-grid">
                <?php foreach ($all_products as $p):
                    $img = get_the_post_thumbnail_url($p->ID, 'product-card') ?: get_template_directory_uri() . '/assets/images/product-placeholder.jpg';
                ?>
                    <a href="<?php echo get_permalink($p->ID); ?>" class="product-card" data-name="<?php echo strtolower($p->post_title); ?>">
                        <div style="position:relative;">
                            <img src="<?php echo $img; ?>" alt="<?php echo esc_attr($p->post_title); ?>">
                            <span style="position:absolute;top:0.5rem;left:0.5rem;background:var(--primary);color:#fff;padding:0.2rem 0.5rem;border-radius:0.375rem;font-size:0.7rem;font-weight:600;">
                                MOQ <?php echo esc_html(get_field('moq', $p->ID)); ?>
                            </span>
                        </div>
                        <div class="product-card-body">
                            <h3><?php echo esc_html($p->post_title); ?></h3>
                            <p class="latin"><?php echo esc_html(get_field('latin_name', $p->ID)); ?></p>
                            <p style="font-size:0.75rem;color:rgba(37,51,40,0.65);margin-top:0.5rem;"><?php echo esc_html(get_field('brief', $p->ID)); ?></p>
                            <div style="display:flex;flex-wrap:wrap;gap:0.25rem;margin-top:0.5rem;">
                                <?php $forms = array_filter(explode(',', get_field('forms', $p->ID))); foreach (array_slice($forms, 0, 4) as $f): ?>
                                    <span style="border:1px solid rgba(23,76,53,0.25);background:rgba(23,76,53,0.05);color:var(--primary);padding:0.1rem 0.3rem;border-radius:0.25rem;font-size:0.65rem;font-weight:500;"><?php echo esc_html(trim($f)); ?></span>
                                <?php endforeach; ?>
                            </div>
                            <span style="display:block;text-align:center;margin-top:0.5rem;border:1px solid rgba(23,76,53,0.3);background:rgba(23,76,53,0.05);color:var(--primary);padding:0.3rem;border-radius:0.375rem;font-size:0.75rem;font-weight:600;">
                                <?php _e('عرض التفاصيل', 'herbs-milanos'); ?>
                            </span>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<script>
// Simple client-side filter
document.addEventListener('DOMContentLoaded', function() {
    var search = document.getElementById('product-search');
    var cards = document.querySelectorAll('#product-grid .product-card');
    var countEl = document.getElementById('product-count');
    var total = cards.length;

    function filter() {
        var q = search.value.toLowerCase();
        var visible = 0;
        cards.forEach(function(card) {
            var name = card.getAttribute('data-name');
            var match = name.indexOf(q) !== -1;
            card.style.display = match ? '' : 'none';
            if (match) visible++;
        });
        countEl.textContent = visible + ' <?php echo __('منتج', 'herbs-milanos'); ?>';
    }

    search.addEventListener('input', filter);
});
</script>

<?php get_footer(); ?>
