<?php if (!defined('ABSPATH')) exit; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> data-scroll-behavior="smooth">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#174c35">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
    <div class="container">
        <a href="<?php echo home_url('/'); ?>" class="logo">
            <span class="logo-icon">🌿</span>
            <span>Herbs Milanos</span>
        </a>
        <nav>
            <?php wp_nav_menu([
                'theme_location' => 'primary',
                'container' => false,
                'menu_class' => 'nav-menu',
                'fallback_cb' => function() {
                    echo '<ul class="nav-menu">
                        <li><a href="/about">' . __('من نحن', 'herbs-milanos') . '</a></li>
                        <li><a href="/products">' . __('المنتجات', 'herbs-milanos') . '</a></li>
                        <li><a href="/resources">' . __('دليل المصدرين', 'herbs-milanos') . '</a></li>
                        <li><a href="/faq">' . __('الأسئلة الشائعة', 'herbs-milanos') . '</a></li>
                        <li><a href="/contact">' . __('اتصل بنا', 'herbs-milanos') . '</a></li>
                    </ul>';
                }
            ]); ?>
        </nav>
        <a href="/contact" class="btn btn-primary" style="font-size:0.85rem;padding:0.5rem 1rem;">
            <?php _e('اطلب عرض سعر', 'herbs-milanos'); ?>
        </a>
    </div>
</header>
