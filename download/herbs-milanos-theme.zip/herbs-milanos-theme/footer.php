<?php if (!defined('ABSPATH')) exit; ?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div>
                <h3>Herbs Milanos</h3>
                <p style="font-size:0.85rem;color:rgba(255,255,255,0.7);margin-top:0.5rem;">
                    Herbs Milanos — Egyptian exporter of herbs, spices, seeds and natural oils since 2000. Own farms in Beni Suef, processing under ISO 22000 & HACCP.
                </p>
            </div>
            <div>
                <h3>Quality & Export</h3>
                <a href="/about">About Herbs Milanos</a>
                <a href="/faq">Quality & certifications</a>
                <a href="/faq">COA & test reports</a>
                <a href="/faq">Phytosanitary documentation</a>
            </div>
            <div>
                <h3>Product Categories</h3>
                <a href="/products?family=herbs-leaves">Herbs & Leaves</a>
                <a href="/products?family=flowers">Flowers</a>
                <a href="/products?family=seeds-spices">Seeds & Spices</a>
            </div>
            <div>
                <h3>Export enquiries</h3>
                <a href="mailto:export@herbsmilanos.com">export@herbsmilanos.com</a>
                <a href="https://wa.me/201226211624">WhatsApp: +20 122 621 1624</a>
                <p style="font-size:0.85rem;color:rgba(255,255,255,0.7);margin-top:0.5rem;">Beni Suef, Egypt</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© <?php echo date('Y'); ?> Herbs Milanos — All rights reserved.</p>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
